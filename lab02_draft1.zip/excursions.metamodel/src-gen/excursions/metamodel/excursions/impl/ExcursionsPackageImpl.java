/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionApp;
import excursions.metamodel.excursions.ExcursionsFactory;
import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.HistoryCulture;
import excursions.metamodel.excursions.NatureOutdoor;
import excursions.metamodel.excursions.ShoppingSightseeing;
import excursions.metamodel.excursions.ThrillAdventure;
import excursions.metamodel.excursions.TripType;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model <b>Package</b>.
 * <!-- end-user-doc -->
 * @generated
 */
public class ExcursionsPackageImpl extends EPackageImpl implements ExcursionsPackage {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass tripTypeEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass excursionAppEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass historyCultureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass natureOutdoorEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass thrillAdventureEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass shoppingSightseeingEClass = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see excursions.metamodel.excursions.ExcursionsPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private ExcursionsPackageImpl() {
		super(eNS_URI, ExcursionsFactory.eINSTANCE);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this model, and for any others upon which it depends.
	 *
	 * <p>This method is used to initialize {@link ExcursionsPackage#eINSTANCE} when that field is accessed.
	 * Clients should not invoke it directly. Instead, they should simply access that field to obtain the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static ExcursionsPackage init() {
		if (isInited)
			return (ExcursionsPackage) EPackage.Registry.INSTANCE.getEPackage(ExcursionsPackage.eNS_URI);

		// Obtain or create and register package
		Object registeredExcursionsPackage = EPackage.Registry.INSTANCE.get(eNS_URI);
		ExcursionsPackageImpl theExcursionsPackage = registeredExcursionsPackage instanceof ExcursionsPackageImpl
				? (ExcursionsPackageImpl) registeredExcursionsPackage
				: new ExcursionsPackageImpl();

		isInited = true;

		// Create package meta-data objects
		theExcursionsPackage.createPackageContents();

		// Initialize created meta-data
		theExcursionsPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theExcursionsPackage.freeze();

		// Update the registry and return the package
		EPackage.Registry.INSTANCE.put(ExcursionsPackage.eNS_URI, theExcursionsPackage);
		return theExcursionsPackage;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getTripType() {
		return tripTypeEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripType_TripID() {
		return (EAttribute) tripTypeEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripType_TripName() {
		return (EAttribute) tripTypeEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripType_Description() {
		return (EAttribute) tripTypeEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripType_Duration() {
		return (EAttribute) tripTypeEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getTripType_Price() {
		return (EAttribute) tripTypeEClass.getEStructuralFeatures().get(4);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripType_Historyculture() {
		return (EReference) tripTypeEClass.getEStructuralFeatures().get(5);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripType_Natureoutdoor() {
		return (EReference) tripTypeEClass.getEStructuralFeatures().get(6);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripType_Thrilladventure() {
		return (EReference) tripTypeEClass.getEStructuralFeatures().get(7);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getTripType_Shoppingsightseeing() {
		return (EReference) tripTypeEClass.getEStructuralFeatures().get(8);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getExcursionApp() {
		return excursionAppEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getExcursionApp_Name() {
		return (EAttribute) excursionAppEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EReference getExcursionApp_Trips() {
		return (EReference) excursionAppEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getHistoryCulture() {
		return historyCultureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getHistoryCulture_HistoricCites() {
		return (EAttribute) historyCultureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getNatureOutdoor() {
		return natureOutdoorEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getNatureOutdoor_NatureCites() {
		return (EAttribute) natureOutdoorEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getThrillAdventure() {
		return thrillAdventureEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getThrillAdventure_Activities() {
		return (EAttribute) thrillAdventureEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EClass getShoppingSightseeing() {
		return shoppingSightseeingEClass;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EAttribute getShoppingSightseeing_Attractions() {
		return (EAttribute) shoppingSightseeingEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExcursionsFactory getExcursionsFactory() {
		return (ExcursionsFactory) getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated)
			return;
		isCreated = true;

		// Create classes and their features
		tripTypeEClass = createEClass(TRIP_TYPE);
		createEAttribute(tripTypeEClass, TRIP_TYPE__TRIP_ID);
		createEAttribute(tripTypeEClass, TRIP_TYPE__TRIP_NAME);
		createEAttribute(tripTypeEClass, TRIP_TYPE__DESCRIPTION);
		createEAttribute(tripTypeEClass, TRIP_TYPE__DURATION);
		createEAttribute(tripTypeEClass, TRIP_TYPE__PRICE);
		createEReference(tripTypeEClass, TRIP_TYPE__HISTORYCULTURE);
		createEReference(tripTypeEClass, TRIP_TYPE__NATUREOUTDOOR);
		createEReference(tripTypeEClass, TRIP_TYPE__THRILLADVENTURE);
		createEReference(tripTypeEClass, TRIP_TYPE__SHOPPINGSIGHTSEEING);

		excursionAppEClass = createEClass(EXCURSION_APP);
		createEAttribute(excursionAppEClass, EXCURSION_APP__NAME);
		createEReference(excursionAppEClass, EXCURSION_APP__TRIPS);

		historyCultureEClass = createEClass(HISTORY_CULTURE);
		createEAttribute(historyCultureEClass, HISTORY_CULTURE__HISTORIC_CITES);

		natureOutdoorEClass = createEClass(NATURE_OUTDOOR);
		createEAttribute(natureOutdoorEClass, NATURE_OUTDOOR__NATURE_CITES);

		thrillAdventureEClass = createEClass(THRILL_ADVENTURE);
		createEAttribute(thrillAdventureEClass, THRILL_ADVENTURE__ACTIVITIES);

		shoppingSightseeingEClass = createEClass(SHOPPING_SIGHTSEEING);
		createEAttribute(shoppingSightseeingEClass, SHOPPING_SIGHTSEEING__ATTRACTIONS);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized)
			return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Create type parameters

		// Set bounds for type parameters

		// Add supertypes to classes
		historyCultureEClass.getESuperTypes().add(this.getTripType());
		natureOutdoorEClass.getESuperTypes().add(this.getTripType());
		thrillAdventureEClass.getESuperTypes().add(this.getTripType());
		shoppingSightseeingEClass.getESuperTypes().add(this.getTripType());

		// Initialize classes, features, and operations; add parameters
		initEClass(tripTypeEClass, TripType.class, "TripType", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getTripType_TripID(), ecorePackage.getEInt(), "TripID", null, 0, 1, TripType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripType_TripName(), ecorePackage.getEString(), "TripName", null, 0, 1, TripType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripType_Description(), ecorePackage.getEString(), "Description", null, 0, 1, TripType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripType_Duration(), ecorePackage.getEInt(), "Duration", null, 0, 1, TripType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getTripType_Price(), ecorePackage.getEFloat(), "Price", null, 0, 1, TripType.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getTripType_Historyculture(), this.getHistoryCulture(), null, "historyculture", null, 0, 1,
				TripType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getTripType_Natureoutdoor(), this.getNatureOutdoor(), null, "natureoutdoor", null, 0, 1,
				TripType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getTripType_Thrilladventure(), this.getThrillAdventure(), null, "thrilladventure", null, 0, 1,
				TripType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES,
				!IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);
		initEReference(getTripType_Shoppingsightseeing(), this.getShoppingSightseeing(), null, "shoppingsightseeing",
				null, 0, 1, TripType.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE,
				IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, IS_DERIVED, IS_ORDERED);

		initEClass(excursionAppEClass, ExcursionApp.class, "ExcursionApp", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getExcursionApp_Name(), ecorePackage.getEString(), "name", null, 0, 1, ExcursionApp.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEReference(getExcursionApp_Trips(), this.getTripType(), null, "Trips", null, 0, -1, ExcursionApp.class,
				!IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, IS_COMPOSITE, !IS_RESOLVE_PROXIES, !IS_UNSETTABLE,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		initEClass(historyCultureEClass, HistoryCulture.class, "HistoryCulture", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getHistoryCulture_HistoricCites(), ecorePackage.getEString(), "historicCites", null, 0, 1,
				HistoryCulture.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(natureOutdoorEClass, NatureOutdoor.class, "NatureOutdoor", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getNatureOutdoor_NatureCites(), ecorePackage.getEString(), "natureCites", null, 0, 1,
				NatureOutdoor.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(thrillAdventureEClass, ThrillAdventure.class, "ThrillAdventure", !IS_ABSTRACT, !IS_INTERFACE,
				IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getThrillAdventure_Activities(), ecorePackage.getEString(), "activities", null, 0, 1,
				ThrillAdventure.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE,
				!IS_DERIVED, IS_ORDERED);

		initEClass(shoppingSightseeingEClass, ShoppingSightseeing.class, "ShoppingSightseeing", !IS_ABSTRACT,
				!IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getShoppingSightseeing_Attractions(), ecorePackage.getEString(), "attractions", null, 0, 1,
				ShoppingSightseeing.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID,
				IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Create resource
		createResource(eNS_URI);
	}

} //ExcursionsPackageImpl
