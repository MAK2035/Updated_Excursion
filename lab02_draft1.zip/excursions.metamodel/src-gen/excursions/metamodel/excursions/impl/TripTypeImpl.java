/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.HistoryCulture;
import excursions.metamodel.excursions.NatureOutdoor;
import excursions.metamodel.excursions.ShoppingSightseeing;
import excursions.metamodel.excursions.ThrillAdventure;
import excursions.metamodel.excursions.TripType;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Trip Type</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getTripID <em>Trip ID</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getTripName <em>Trip Name</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getDescription <em>Description</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getDuration <em>Duration</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getPrice <em>Price</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getHistoryculture <em>Historyculture</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getNatureoutdoor <em>Natureoutdoor</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getThrilladventure <em>Thrilladventure</em>}</li>
 *   <li>{@link excursions.metamodel.excursions.impl.TripTypeImpl#getShoppingsightseeing <em>Shoppingsightseeing</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class TripTypeImpl extends MinimalEObjectImpl.Container implements TripType {
	/**
	 * The default value of the '{@link #getTripID() <em>Trip ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripID()
	 * @generated
	 * @ordered
	 */
	protected static final int TRIP_ID_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getTripID() <em>Trip ID</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripID()
	 * @generated
	 * @ordered
	 */
	protected int tripID = TRIP_ID_EDEFAULT;

	/**
	 * The default value of the '{@link #getTripName() <em>Trip Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripName()
	 * @generated
	 * @ordered
	 */
	protected static final String TRIP_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getTripName() <em>Trip Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTripName()
	 * @generated
	 * @ordered
	 */
	protected String tripName = TRIP_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected static final String DESCRIPTION_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getDescription() <em>Description</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDescription()
	 * @generated
	 * @ordered
	 */
	protected String description = DESCRIPTION_EDEFAULT;

	/**
	 * The default value of the '{@link #getDuration() <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDuration()
	 * @generated
	 * @ordered
	 */
	protected static final int DURATION_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getDuration() <em>Duration</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getDuration()
	 * @generated
	 * @ordered
	 */
	protected int duration = DURATION_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final float PRICE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected float price = PRICE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getHistoryculture() <em>Historyculture</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getHistoryculture()
	 * @generated
	 * @ordered
	 */
	protected HistoryCulture historyculture;

	/**
	 * The cached value of the '{@link #getNatureoutdoor() <em>Natureoutdoor</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getNatureoutdoor()
	 * @generated
	 * @ordered
	 */
	protected NatureOutdoor natureoutdoor;

	/**
	 * The cached value of the '{@link #getThrilladventure() <em>Thrilladventure</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getThrilladventure()
	 * @generated
	 * @ordered
	 */
	protected ThrillAdventure thrilladventure;

	/**
	 * The cached value of the '{@link #getShoppingsightseeing() <em>Shoppingsightseeing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShoppingsightseeing()
	 * @generated
	 * @ordered
	 */
	protected ShoppingSightseeing shoppingsightseeing;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TripTypeImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExcursionsPackage.Literals.TRIP_TYPE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getTripID() {
		return tripID;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTripID(int newTripID) {
		int oldTripID = tripID;
		tripID = newTripID;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__TRIP_ID, oldTripID,
					tripID));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getTripName() {
		return tripName;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setTripName(String newTripName) {
		String oldTripName = tripName;
		tripName = newTripName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__TRIP_NAME, oldTripName,
					tripName));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDescription(String newDescription) {
		String oldDescription = description;
		description = newDescription;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__DESCRIPTION,
					oldDescription, description));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getDuration() {
		return duration;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDuration(int newDuration) {
		int oldDuration = duration;
		duration = newDuration;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__DURATION, oldDuration,
					duration));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPrice(float newPrice) {
		float oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__PRICE, oldPrice, price));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HistoryCulture getHistoryculture() {
		if (historyculture != null && historyculture.eIsProxy()) {
			InternalEObject oldHistoryculture = (InternalEObject) historyculture;
			historyculture = (HistoryCulture) eResolveProxy(oldHistoryculture);
			if (historyculture != oldHistoryculture) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE, oldHistoryculture, historyculture));
			}
		}
		return historyculture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public HistoryCulture basicGetHistoryculture() {
		return historyculture;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setHistoryculture(HistoryCulture newHistoryculture) {
		HistoryCulture oldHistoryculture = historyculture;
		historyculture = newHistoryculture;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE,
					oldHistoryculture, historyculture));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NatureOutdoor getNatureoutdoor() {
		if (natureoutdoor != null && natureoutdoor.eIsProxy()) {
			InternalEObject oldNatureoutdoor = (InternalEObject) natureoutdoor;
			natureoutdoor = (NatureOutdoor) eResolveProxy(oldNatureoutdoor);
			if (natureoutdoor != oldNatureoutdoor) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR, oldNatureoutdoor, natureoutdoor));
			}
		}
		return natureoutdoor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NatureOutdoor basicGetNatureoutdoor() {
		return natureoutdoor;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setNatureoutdoor(NatureOutdoor newNatureoutdoor) {
		NatureOutdoor oldNatureoutdoor = natureoutdoor;
		natureoutdoor = newNatureoutdoor;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR,
					oldNatureoutdoor, natureoutdoor));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThrillAdventure getThrilladventure() {
		if (thrilladventure != null && thrilladventure.eIsProxy()) {
			InternalEObject oldThrilladventure = (InternalEObject) thrilladventure;
			thrilladventure = (ThrillAdventure) eResolveProxy(oldThrilladventure);
			if (thrilladventure != oldThrilladventure) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE, oldThrilladventure, thrilladventure));
			}
		}
		return thrilladventure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ThrillAdventure basicGetThrilladventure() {
		return thrilladventure;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setThrilladventure(ThrillAdventure newThrilladventure) {
		ThrillAdventure oldThrilladventure = thrilladventure;
		thrilladventure = newThrilladventure;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE,
					oldThrilladventure, thrilladventure));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShoppingSightseeing getShoppingsightseeing() {
		if (shoppingsightseeing != null && shoppingsightseeing.eIsProxy()) {
			InternalEObject oldShoppingsightseeing = (InternalEObject) shoppingsightseeing;
			shoppingsightseeing = (ShoppingSightseeing) eResolveProxy(oldShoppingsightseeing);
			if (shoppingsightseeing != oldShoppingsightseeing) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE,
							ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING, oldShoppingsightseeing,
							shoppingsightseeing));
			}
		}
		return shoppingsightseeing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ShoppingSightseeing basicGetShoppingsightseeing() {
		return shoppingsightseeing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setShoppingsightseeing(ShoppingSightseeing newShoppingsightseeing) {
		ShoppingSightseeing oldShoppingsightseeing = shoppingsightseeing;
		shoppingsightseeing = newShoppingsightseeing;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING,
					oldShoppingsightseeing, shoppingsightseeing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ExcursionsPackage.TRIP_TYPE__TRIP_ID:
			return getTripID();
		case ExcursionsPackage.TRIP_TYPE__TRIP_NAME:
			return getTripName();
		case ExcursionsPackage.TRIP_TYPE__DESCRIPTION:
			return getDescription();
		case ExcursionsPackage.TRIP_TYPE__DURATION:
			return getDuration();
		case ExcursionsPackage.TRIP_TYPE__PRICE:
			return getPrice();
		case ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE:
			if (resolve)
				return getHistoryculture();
			return basicGetHistoryculture();
		case ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR:
			if (resolve)
				return getNatureoutdoor();
			return basicGetNatureoutdoor();
		case ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE:
			if (resolve)
				return getThrilladventure();
			return basicGetThrilladventure();
		case ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING:
			if (resolve)
				return getShoppingsightseeing();
			return basicGetShoppingsightseeing();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ExcursionsPackage.TRIP_TYPE__TRIP_ID:
			setTripID((Integer) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__TRIP_NAME:
			setTripName((String) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__DESCRIPTION:
			setDescription((String) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__DURATION:
			setDuration((Integer) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__PRICE:
			setPrice((Float) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE:
			setHistoryculture((HistoryCulture) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR:
			setNatureoutdoor((NatureOutdoor) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE:
			setThrilladventure((ThrillAdventure) newValue);
			return;
		case ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING:
			setShoppingsightseeing((ShoppingSightseeing) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.TRIP_TYPE__TRIP_ID:
			setTripID(TRIP_ID_EDEFAULT);
			return;
		case ExcursionsPackage.TRIP_TYPE__TRIP_NAME:
			setTripName(TRIP_NAME_EDEFAULT);
			return;
		case ExcursionsPackage.TRIP_TYPE__DESCRIPTION:
			setDescription(DESCRIPTION_EDEFAULT);
			return;
		case ExcursionsPackage.TRIP_TYPE__DURATION:
			setDuration(DURATION_EDEFAULT);
			return;
		case ExcursionsPackage.TRIP_TYPE__PRICE:
			setPrice(PRICE_EDEFAULT);
			return;
		case ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE:
			setHistoryculture((HistoryCulture) null);
			return;
		case ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR:
			setNatureoutdoor((NatureOutdoor) null);
			return;
		case ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE:
			setThrilladventure((ThrillAdventure) null);
			return;
		case ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING:
			setShoppingsightseeing((ShoppingSightseeing) null);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.TRIP_TYPE__TRIP_ID:
			return tripID != TRIP_ID_EDEFAULT;
		case ExcursionsPackage.TRIP_TYPE__TRIP_NAME:
			return TRIP_NAME_EDEFAULT == null ? tripName != null : !TRIP_NAME_EDEFAULT.equals(tripName);
		case ExcursionsPackage.TRIP_TYPE__DESCRIPTION:
			return DESCRIPTION_EDEFAULT == null ? description != null : !DESCRIPTION_EDEFAULT.equals(description);
		case ExcursionsPackage.TRIP_TYPE__DURATION:
			return duration != DURATION_EDEFAULT;
		case ExcursionsPackage.TRIP_TYPE__PRICE:
			return price != PRICE_EDEFAULT;
		case ExcursionsPackage.TRIP_TYPE__HISTORYCULTURE:
			return historyculture != null;
		case ExcursionsPackage.TRIP_TYPE__NATUREOUTDOOR:
			return natureoutdoor != null;
		case ExcursionsPackage.TRIP_TYPE__THRILLADVENTURE:
			return thrilladventure != null;
		case ExcursionsPackage.TRIP_TYPE__SHOPPINGSIGHTSEEING:
			return shoppingsightseeing != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (TripID: ");
		result.append(tripID);
		result.append(", TripName: ");
		result.append(tripName);
		result.append(", Description: ");
		result.append(description);
		result.append(", Duration: ");
		result.append(duration);
		result.append(", Price: ");
		result.append(price);
		result.append(')');
		return result.toString();
	}

} //TripTypeImpl
