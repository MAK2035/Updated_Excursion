/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.ThrillAdventure;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Thrill Adventure</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.impl.ThrillAdventureImpl#getActivities <em>Activities</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ThrillAdventureImpl extends TripTypeImpl implements ThrillAdventure {
	/**
	 * The default value of the '{@link #getActivities() <em>Activities</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivities()
	 * @generated
	 * @ordered
	 */
	protected static final String ACTIVITIES_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getActivities() <em>Activities</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getActivities()
	 * @generated
	 * @ordered
	 */
	protected String activities = ACTIVITIES_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ThrillAdventureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExcursionsPackage.Literals.THRILL_ADVENTURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getActivities() {
		return activities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setActivities(String newActivities) {
		String oldActivities = activities;
		activities = newActivities;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.THRILL_ADVENTURE__ACTIVITIES,
					oldActivities, activities));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ExcursionsPackage.THRILL_ADVENTURE__ACTIVITIES:
			return getActivities();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ExcursionsPackage.THRILL_ADVENTURE__ACTIVITIES:
			setActivities((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.THRILL_ADVENTURE__ACTIVITIES:
			setActivities(ACTIVITIES_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.THRILL_ADVENTURE__ACTIVITIES:
			return ACTIVITIES_EDEFAULT == null ? activities != null : !ACTIVITIES_EDEFAULT.equals(activities);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (activities: ");
		result.append(activities);
		result.append(')');
		return result.toString();
	}

} //ThrillAdventureImpl
