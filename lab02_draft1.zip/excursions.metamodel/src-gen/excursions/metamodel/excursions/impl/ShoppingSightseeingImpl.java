/**
 */
package excursions.metamodel.excursions.impl;

import excursions.metamodel.excursions.ExcursionsPackage;
import excursions.metamodel.excursions.ShoppingSightseeing;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Shopping Sightseeing</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.impl.ShoppingSightseeingImpl#getAttractions <em>Attractions</em>}</li>
 * </ul>
 *
 * @generated
 */
public class ShoppingSightseeingImpl extends TripTypeImpl implements ShoppingSightseeing {
	/**
	 * The default value of the '{@link #getAttractions() <em>Attractions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttractions()
	 * @generated
	 * @ordered
	 */
	protected static final String ATTRACTIONS_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getAttractions() <em>Attractions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttractions()
	 * @generated
	 * @ordered
	 */
	protected String attractions = ATTRACTIONS_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ShoppingSightseeingImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ExcursionsPackage.Literals.SHOPPING_SIGHTSEEING;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String getAttractions() {
		return attractions;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setAttractions(String newAttractions) {
		String oldAttractions = attractions;
		attractions = newAttractions;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, ExcursionsPackage.SHOPPING_SIGHTSEEING__ATTRACTIONS,
					oldAttractions, attractions));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
		case ExcursionsPackage.SHOPPING_SIGHTSEEING__ATTRACTIONS:
			return getAttractions();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
		case ExcursionsPackage.SHOPPING_SIGHTSEEING__ATTRACTIONS:
			setAttractions((String) newValue);
			return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.SHOPPING_SIGHTSEEING__ATTRACTIONS:
			setAttractions(ATTRACTIONS_EDEFAULT);
			return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
		case ExcursionsPackage.SHOPPING_SIGHTSEEING__ATTRACTIONS:
			return ATTRACTIONS_EDEFAULT == null ? attractions != null : !ATTRACTIONS_EDEFAULT.equals(attractions);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		if (eIsProxy())
			return super.toString();

		StringBuilder result = new StringBuilder(super.toString());
		result.append(" (attractions: ");
		result.append(attractions);
		result.append(')');
		return result.toString();
	}

} //ShoppingSightseeingImpl
