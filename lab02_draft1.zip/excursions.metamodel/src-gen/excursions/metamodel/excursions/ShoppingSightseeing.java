/**
 */
package excursions.metamodel.excursions;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Shopping Sightseeing</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.ShoppingSightseeing#getAttractions <em>Attractions</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getShoppingSightseeing()
 * @model
 * @generated
 */
public interface ShoppingSightseeing extends TripType {
	/**
	 * Returns the value of the '<em><b>Attractions</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attractions</em>' attribute.
	 * @see #setAttractions(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getShoppingSightseeing_Attractions()
	 * @model
	 * @generated
	 */
	String getAttractions();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.ShoppingSightseeing#getAttractions <em>Attractions</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Attractions</em>' attribute.
	 * @see #getAttractions()
	 * @generated
	 */
	void setAttractions(String value);

} // ShoppingSightseeing
