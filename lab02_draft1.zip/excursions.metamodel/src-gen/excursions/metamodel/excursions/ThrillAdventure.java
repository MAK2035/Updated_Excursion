/**
 */
package excursions.metamodel.excursions;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Thrill Adventure</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.ThrillAdventure#getActivities <em>Activities</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getThrillAdventure()
 * @model
 * @generated
 */
public interface ThrillAdventure extends TripType {
	/**
	 * Returns the value of the '<em><b>Activities</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Activities</em>' attribute.
	 * @see #setActivities(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getThrillAdventure_Activities()
	 * @model
	 * @generated
	 */
	String getActivities();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.ThrillAdventure#getActivities <em>Activities</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Activities</em>' attribute.
	 * @see #getActivities()
	 * @generated
	 */
	void setActivities(String value);

} // ThrillAdventure
