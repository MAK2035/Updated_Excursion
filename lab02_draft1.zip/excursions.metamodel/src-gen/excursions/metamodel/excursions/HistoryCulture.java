/**
 */
package excursions.metamodel.excursions;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>History Culture</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link excursions.metamodel.excursions.HistoryCulture#getHistoricCites <em>Historic Cites</em>}</li>
 * </ul>
 *
 * @see excursions.metamodel.excursions.ExcursionsPackage#getHistoryCulture()
 * @model
 * @generated
 */
public interface HistoryCulture extends TripType {
	/**
	 * Returns the value of the '<em><b>Historic Cites</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Historic Cites</em>' attribute.
	 * @see #setHistoricCites(String)
	 * @see excursions.metamodel.excursions.ExcursionsPackage#getHistoryCulture_HistoricCites()
	 * @model
	 * @generated
	 */
	String getHistoricCites();

	/**
	 * Sets the value of the '{@link excursions.metamodel.excursions.HistoryCulture#getHistoricCites <em>Historic Cites</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Historic Cites</em>' attribute.
	 * @see #getHistoricCites()
	 * @generated
	 */
	void setHistoricCites(String value);

} // HistoryCulture
