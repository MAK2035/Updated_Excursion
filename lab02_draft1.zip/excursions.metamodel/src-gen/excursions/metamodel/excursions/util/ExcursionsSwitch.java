/**
 */
package excursions.metamodel.excursions.util;

import excursions.metamodel.excursions.*;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.Switch;

/**
 * <!-- begin-user-doc -->
 * The <b>Switch</b> for the model's inheritance hierarchy.
 * It supports the call {@link #doSwitch(EObject) doSwitch(object)}
 * to invoke the <code>caseXXX</code> method for each class of the model,
 * starting with the actual class of the object
 * and proceeding up the inheritance hierarchy
 * until a non-null result is returned,
 * which is the result of the switch.
 * <!-- end-user-doc -->
 * @see excursions.metamodel.excursions.ExcursionsPackage
 * @generated
 */
public class ExcursionsSwitch<T> extends Switch<T> {
	/**
	 * The cached model package
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected static ExcursionsPackage modelPackage;

	/**
	 * Creates an instance of the switch.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public ExcursionsSwitch() {
		if (modelPackage == null) {
			modelPackage = ExcursionsPackage.eINSTANCE;
		}
	}

	/**
	 * Checks whether this is a switch for the given package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param ePackage the package in question.
	 * @return whether this is a switch for the given package.
	 * @generated
	 */
	@Override
	protected boolean isSwitchFor(EPackage ePackage) {
		return ePackage == modelPackage;
	}

	/**
	 * Calls <code>caseXXX</code> for each class of the model until one returns a non null result; it yields that result.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the first non-null result returned by a <code>caseXXX</code> call.
	 * @generated
	 */
	@Override
	protected T doSwitch(int classifierID, EObject theEObject) {
		switch (classifierID) {
		case ExcursionsPackage.TRIP_TYPE: {
			TripType tripType = (TripType) theEObject;
			T result = caseTripType(tripType);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ExcursionsPackage.EXCURSION_APP: {
			ExcursionApp excursionApp = (ExcursionApp) theEObject;
			T result = caseExcursionApp(excursionApp);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ExcursionsPackage.HISTORY_CULTURE: {
			HistoryCulture historyCulture = (HistoryCulture) theEObject;
			T result = caseHistoryCulture(historyCulture);
			if (result == null)
				result = caseTripType(historyCulture);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ExcursionsPackage.NATURE_OUTDOOR: {
			NatureOutdoor natureOutdoor = (NatureOutdoor) theEObject;
			T result = caseNatureOutdoor(natureOutdoor);
			if (result == null)
				result = caseTripType(natureOutdoor);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ExcursionsPackage.THRILL_ADVENTURE: {
			ThrillAdventure thrillAdventure = (ThrillAdventure) theEObject;
			T result = caseThrillAdventure(thrillAdventure);
			if (result == null)
				result = caseTripType(thrillAdventure);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		case ExcursionsPackage.SHOPPING_SIGHTSEEING: {
			ShoppingSightseeing shoppingSightseeing = (ShoppingSightseeing) theEObject;
			T result = caseShoppingSightseeing(shoppingSightseeing);
			if (result == null)
				result = caseTripType(shoppingSightseeing);
			if (result == null)
				result = defaultCase(theEObject);
			return result;
		}
		default:
			return defaultCase(theEObject);
		}
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Trip Type</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Trip Type</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseTripType(TripType object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Excursion App</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Excursion App</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseExcursionApp(ExcursionApp object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>History Culture</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>History Culture</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseHistoryCulture(HistoryCulture object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Nature Outdoor</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Nature Outdoor</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseNatureOutdoor(NatureOutdoor object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Thrill Adventure</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Thrill Adventure</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseThrillAdventure(ThrillAdventure object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>Shopping Sightseeing</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>Shopping Sightseeing</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject) doSwitch(EObject)
	 * @generated
	 */
	public T caseShoppingSightseeing(ShoppingSightseeing object) {
		return null;
	}

	/**
	 * Returns the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * <!-- begin-user-doc -->
	 * This implementation returns null;
	 * returning a non-null result will terminate the switch, but this is the last case anyway.
	 * <!-- end-user-doc -->
	 * @param object the target of the switch.
	 * @return the result of interpreting the object as an instance of '<em>EObject</em>'.
	 * @see #doSwitch(org.eclipse.emf.ecore.EObject)
	 * @generated
	 */
	@Override
	public T defaultCase(EObject object) {
		return null;
	}

} //ExcursionsSwitch
