/**
 */
package excursions.metamodel.excursions;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see excursions.metamodel.excursions.ExcursionsPackage
 * @generated
 */
public interface ExcursionsFactory extends EFactory {
	/**
	 * The singleton instance of the factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	ExcursionsFactory eINSTANCE = excursions.metamodel.excursions.impl.ExcursionsFactoryImpl.init();

	/**
	 * Returns a new object of class '<em>Excursion App</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Excursion App</em>'.
	 * @generated
	 */
	ExcursionApp createExcursionApp();

	/**
	 * Returns a new object of class '<em>History Culture</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>History Culture</em>'.
	 * @generated
	 */
	HistoryCulture createHistoryCulture();

	/**
	 * Returns a new object of class '<em>Nature Outdoor</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Nature Outdoor</em>'.
	 * @generated
	 */
	NatureOutdoor createNatureOutdoor();

	/**
	 * Returns a new object of class '<em>Thrill Adventure</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Thrill Adventure</em>'.
	 * @generated
	 */
	ThrillAdventure createThrillAdventure();

	/**
	 * Returns a new object of class '<em>Shopping Sightseeing</em>'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return a new object of class '<em>Shopping Sightseeing</em>'.
	 * @generated
	 */
	ShoppingSightseeing createShoppingSightseeing();

	/**
	 * Returns the package supported by this factory.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the package supported by this factory.
	 * @generated
	 */
	ExcursionsPackage getExcursionsPackage();

} //ExcursionsFactory
